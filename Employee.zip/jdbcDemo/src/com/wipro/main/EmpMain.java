package com.wipro.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.wipro.bean.Employee;
import com.wipro.dao.EmpDAO;

public class EmpMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter \"1\" to insert" );
		switch(sc.nextInt())
		{
		case 1:
				Employee e=new Employee();
				System.out.println("Enter employee id");
				e.setEid(sc.nextInt());
				System.out.println("Enter employee name");
				e.setName(sc.next());
				System.out.println("Enter Date of Birth");
				SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
				Date d=null;
				try
				{
					 d=sdf.parse(sc.next());
				}
				catch(ParseException p)
				{
					p.printStackTrace();
				}
				e.setDob(d);
				System.out.println("Enter the Gender");
				e.setGender(sc.next().charAt(0));
				System.out.println("Enter the salary");
				e.setSalary(sc.nextDouble());
				EmpDAO edao=new EmpDAO();
				String r=edao.empInsert(e);
				System.out.println(r);
				break;
		case 2:
				
		case 3:
			
		case 4:
		
		default:
			System.out.println("Illegal entry");
			break;
		}
		sc.close();
	}

}

package com.wipro.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.wipro.bean.Employee;
import com.wipro.dao.EmpDAO;

public class EmpMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter \"1\" to Insert" );
		System.out.println("\tEnter \"2\" to Update");
		System.out.print("Enter \"3\" to Delete");
		System.out.println("\t Enter \"4\" to Select a row by id");
		switch(sc.nextInt())
		{
		case 1:
				Employee e=new Employee();
				System.out.println("Enter employee id");
				e.setEid(sc.nextInt());
				System.out.println("Enter employee name");
				e.setName(sc.next());
				System.out.println("Enter Date of Birth in format of dd-mm-yyyy");
				SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
				Date d=null;
				try
				{
					 d=sdf.parse(sc.next());
				}
				catch(ParseException p)
				{
					p.printStackTrace();
				}
				e.setDob(d);
				System.out.println("Enter the Gender");
				e.setGender(sc.next().charAt(0));
				System.out.println("Enter the salary");
				e.setSalary(sc.nextDouble());
				EmpDAO edao=new EmpDAO();
				String r=edao.empInsert(e);
				System.out.println(r);
				break;
		case 2:
				System.out.println("Enter the id to update the salary");
				int id=sc.nextInt();
				double d1=sc.nextDouble();
				EmpDAO edao1=new EmpDAO();
				String t=edao1.empUpdate(d1, id);
				System.out.println(t);
				break;
		case 3:
			System.out.println("Enter the id to Delete");
			int i=sc.nextInt();
			EmpDAO edao3=new EmpDAO();
			String t1=edao3.empDelete(i);
			System.out.println(t1);
			break;
		case 4:
			System.out.println("Enter the id to retreive the values");
			int p=sc.nextInt();
			EmpDAO dataSelect=new EmpDAO();
			dataSelect.empSelect(p);
			break;
		default:
			System.out.println("Illegal entry");
			break;
		}
		sc.close();
	}

}

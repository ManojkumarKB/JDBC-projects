package com.wipro.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;

import com.wipro.bean.Employee;
import com.wipro.util.DBUtil;
public class EmpDAO
{
	public String empInsert(Employee e)
	{
		Connection con=null;
		String r="";
		int i=0;
		try
		{
			con=DBUtil.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into employee values(?,?,?,?,?)");
			ps.setInt(1,e.getEid());
			ps.setString(2,e.getName());
			ps.setDate(3,new Date(e.getDob().getTime()));
			ps.setString(4,""+ e.getGender());
			ps.setDouble(5, e.getSalary());
			i=ps.executeUpdate();
			con.close();
		}
		catch(SQLException e1)
		{	
			e1.printStackTrace();
		}
		if(i==1)
		{
			r="Insert Success";
		}
		else
		{
			r="Insert Fail";
		}
		return r;
	}
	public String empUpdate(double d,int id)
	{
		Connection con=DBUtil.getConnection();
		String s="";
		try
		{
			PreparedStatement ps=con.prepareStatement("UPDATE employee SET salary=? WHERE eid=?");
			ps.setDouble(1, d);
			ps.setInt(2,id);
			int i=ps.executeUpdate();
			if(i==1)
			{
				s="Update Successfull";
			}
			else
			{
				s="Update unsuccessfull";
			}
		}
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		return s;
	}
	public String empDelete(int id)
	{
		Connection con=DBUtil.getConnection();
		String str="";
		try
		{
			PreparedStatement ps=con.prepareStatement("DELETE FROM employee WHERE eid=?");
			ps.setInt(1,id);
			int j=ps.executeUpdate();
			if(j!=0)
			{
				str="Deleted Successfully";
			}
			else
			{
				str="Deletion unsuccessfull";
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return str;
	}
	public void empSelect(int i)
	{
		Connection con=DBUtil.getConnection();
		try
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM employee WHERE eid=?");
			ps.setInt(1, i);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				int n=rs.getInt(1);
				String name=rs.getString(2);
				Date Date=rs.getDate(3);
				String gender=rs.getString(4);
				double d=rs.getDouble(5);
				System.out.println("Id is "+n+" name "+name+" Date "+Date+" Gender is "+gender+" and salary is +  "+d);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
}
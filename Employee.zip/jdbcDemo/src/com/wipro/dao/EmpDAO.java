package com.wipro.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import com.wipro.bean.Employee;
import com.wipro.util.DBUtil;
public class EmpDAO
{
	public String empInsert(Employee e)
	{
		Connection con=null;
		String r="";
		int i=0;
		try
		{
			con=DBUtil.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into employee values(?,?,?,?,?)");
			ps.setInt(1,e.getEid());
			ps.setString(2,e.getName());
			ps.setDate(3,new Date(e.getDob().getTime()));
			ps.setString(4,""+ e.getGender());
			ps.setDouble(5, e.getSalary());
			i=ps.executeUpdate();
			con.close();
		}
		catch(SQLException e1)
		{	
			e1.printStackTrace();
		}
		if(i==1)
		{
			r="Insert Success";
		}
		else
		{
			r="Insert Fail";
		}
		return r;
	}
	public String emp
	
}